# using the matlab in folder matlab_fiber_compressionandrepresentation_stage3
# run the script "generate_process_python_output_stage3.m"

#this step is for writing matlab code in each folder of the processed
# HCP file. The writen matlab is for processing python output. 
# The following things are done:
# 1. resample each streamlines;
# 2. remove outliers
# 3. save everthing into matrix format