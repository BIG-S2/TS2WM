#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import print_function

if __name__ == '__main__':
    print('WARNING: This script has been deprecated.\nUse the new Nextflow '
          'tractometry pipeline located at '
          'https://bitbucket.org/sciludes/tractometry-nf')
